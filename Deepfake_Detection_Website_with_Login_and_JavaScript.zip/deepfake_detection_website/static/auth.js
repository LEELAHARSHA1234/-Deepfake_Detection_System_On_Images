// Authentication page helpers: password visibility and basic client-side validation.
document.querySelectorAll('[data-toggle-password]').forEach((button) => {
  button.addEventListener('click', () => {
    const input = document.getElementById(button.dataset.togglePassword);
    if (!input) return;
    const visible = input.type === 'password';
    input.type = visible ? 'text' : 'password';
    button.textContent = visible ? 'Hide' : 'Show';
    button.setAttribute('aria-label', visible ? 'Hide password' : 'Show password');
  });
});
const form = document.querySelector('.auth-form');
if (form) {
  form.addEventListener('submit', (event) => {
    const error = document.getElementById('formError');
    if (error) error.textContent = '';
    const password = document.getElementById('password');
    const confirm = document.getElementById('confirm_password');
    if (password && password.value.length < 8 && confirm) {
      event.preventDefault();
      password.classList.add('invalid');
      if (error) error.textContent = 'Password must be at least 8 characters.';
      password.focus();
      return;
    }
    if (password && confirm && password.value !== confirm.value) {
      event.preventDefault();
      confirm.classList.add('invalid');
      if (error) error.textContent = 'Passwords do not match.';
      confirm.focus();
      return;
    }
    const submit = form.querySelector('.auth-submit');
    if (submit) {
      submit.classList.add('is-loading');
      submit.disabled = true;
      const span = submit.querySelector('span');
      if (span) span.textContent = '…';
    }
  });
  form.querySelectorAll('input').forEach((input) => {
    input.addEventListener('input', () => input.classList.remove('invalid'));
  });
}
