Deepfake Image Classifier — trained on your Sample_fake_images dataset

Dataset: 5 fake images + 5 real images (10 total)
Split: 8 training images (4/class), 2 validation images (1/class)
Model: small CNN trained from scratch using PyTorch
Image size: 96x96

Files:
- deepfake_image_model.pth : trained weights
- train_model.py           : training script
- predict_image.py         : prediction script for a new image
- dataset/                 : the extracted original images in fake/ and real/

Install packages:
    pip install torch torchvision pillow

Train:
    python train_model.py

Predict an image:
    python predict_image.py path/to/image.jpg

Important limitation:
This dataset is extremely small. The model's 100% validation accuracy was on
only 2 images, and it reached 100% training accuracy. This is not a reliable
estimate of performance on unseen images. Add a much larger, diverse dataset
before using it for a real deepfake-detection claim or demonstration.
