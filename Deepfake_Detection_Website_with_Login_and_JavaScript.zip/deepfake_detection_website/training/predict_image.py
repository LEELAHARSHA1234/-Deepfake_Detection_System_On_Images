"""Predict REAL/FAKE for a single image using deepfake_image_model.pth."""
import os, sys
from PIL import Image
import torch
from torch import nn
from torchvision import transforms

BASE=os.path.dirname(os.path.abspath(__file__))
MODEL=os.path.join(BASE,'deepfake_image_model.pth')
class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features=nn.Sequential(
            nn.Conv2d(3,16,3,padding=1),nn.BatchNorm2d(16),nn.ReLU(),nn.MaxPool2d(2),
            nn.Conv2d(16,32,3,padding=1),nn.BatchNorm2d(32),nn.ReLU(),nn.MaxPool2d(2),
            nn.Conv2d(32,64,3,padding=1),nn.BatchNorm2d(64),nn.ReLU(),nn.MaxPool2d(2),
            nn.Conv2d(64,96,3,padding=1),nn.BatchNorm2d(96),nn.ReLU(),nn.AdaptiveAvgPool2d((1,1)))
        self.classifier=nn.Sequential(nn.Flatten(),nn.Dropout(0.35),nn.Linear(96,2))
    def forward(self,x): return self.classifier(self.features(x))

if len(sys.argv)<2:
    print('Usage: python predict_image.py path/to/image.jpg'); sys.exit(1)
path=sys.argv[1]
checkpoint=torch.load(MODEL,map_location='cpu',weights_only=False)
model=SmallCNN(); model.load_state_dict(checkpoint['model_state_dict']); model.eval()
transform=transforms.Compose([transforms.Resize((96,96)),transforms.ToTensor(),transforms.Normalize((0.5,)*3,(0.5,)*3)])
image=Image.open(path).convert('RGB')
x=transform(image).unsqueeze(0)
with torch.no_grad(): probs=torch.softmax(model(x),dim=1)[0]
classes=checkpoint['classes']; index=int(probs.argmax()); label=classes[index]
print(f'Prediction: {label.upper()}')
print(f'Model score: {probs[index].item()*100:.2f}%')
print('Scores:', {classes[i]:round(probs[i].item()*100,2) for i in range(len(classes))})
print('NOTE: This model was trained on only 10 images and is not reliable for real-world detection.')
