"""Train a small REAL-vs-FAKE image classifier from the supplied 10-image dataset.
Dataset folder: dataset/fake and dataset/real
This is a demonstration baseline; 10 images are not enough for generalization.
"""
import os, random, copy
from PIL import Image, ImageEnhance
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'dataset')
MODEL_PATH = os.path.join(BASE_DIR, 'deepfake_image_model.pth')
CLASSES = ['fake', 'real']  # output index 0=fake, 1=real
SEED = 42
random.seed(SEED); torch.manual_seed(SEED)

class ImageDataset(Dataset):
    def __init__(self, records, transform=None):
        self.records, self.transform = records, transform
    def __len__(self): return len(self.records)
    def __getitem__(self, idx):
        path, label = self.records[idx]
        image = Image.open(path).convert('RGB')
        if self.transform: image = self.transform(image)
        return image, label

class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 16, 3, padding=1), nn.BatchNorm2d(16), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 96, 3, padding=1), nn.BatchNorm2d(96), nn.ReLU(), nn.AdaptiveAvgPool2d((1,1))
        )
        self.classifier = nn.Sequential(nn.Flatten(), nn.Dropout(0.35), nn.Linear(96, 2))
    def forward(self, x): return self.classifier(self.features(x))

all_records=[]
for label, cls in enumerate(CLASSES):
    folder=os.path.join(DATA_DIR,cls)
    files=sorted([os.path.join(folder,f) for f in os.listdir(folder) if f.lower().endswith(('.jpg','.jpeg','.png'))])
    if len(files)<2: raise RuntimeError(f'Need at least 2 images in {folder}; found {len(files)}')
    random.shuffle(files)
    # With 5 images/class: 4 train, 1 validation per class.
    val_count=max(1, round(len(files)*0.2))
    all_records += [(p,label) for p in files[val_count:]]
    val_records = [(p,label) for p in files[:val_count]] if label==0 else val_records + [(p,label) for p in files[:val_count]]

train_transform=transforms.Compose([
    transforms.Resize((96,96)),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.RandomRotation(8),
    transforms.ColorJitter(brightness=0.08, contrast=0.08, saturation=0.06),
    transforms.ToTensor(),
    transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
])
val_transform=transforms.Compose([
    transforms.Resize((96,96)), transforms.ToTensor(),
    transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
])
train_loader=DataLoader(ImageDataset(all_records,train_transform),batch_size=4,shuffle=True)
val_loader=DataLoader(ImageDataset(val_records,val_transform),batch_size=2,shuffle=False)
model=SmallCNN()
criterion=nn.CrossEntropyLoss()
optimizer=torch.optim.Adam(model.parameters(),lr=0.001,weight_decay=0.001)

best_acc=-1; best_state=copy.deepcopy(model.state_dict())
for epoch in range(1,61):
    model.train(); running=0; correct=0; total=0
    for x,y in train_loader:
        optimizer.zero_grad(); out=model(x); loss=criterion(out,y); loss.backward(); optimizer.step()
        running += loss.item()*y.size(0); correct += (out.argmax(1)==y).sum().item(); total += y.size(0)
    model.eval(); val_correct=0; val_total=0; val_loss=0
    with torch.no_grad():
        for x,y in val_loader:
            out=model(x); val_loss += criterion(out,y).item()*y.size(0)
            val_correct += (out.argmax(1)==y).sum().item(); val_total += y.size(0)
    val_acc=val_correct/max(val_total,1)
    if val_acc>best_acc:
        best_acc=val_acc; best_state=copy.deepcopy(model.state_dict())
    if epoch in (1,10,20,30,40,50,60):
        print(f'Epoch {epoch:02d}/60 | train_loss={running/total:.4f} | train_acc={correct/total:.2%} | val_loss={val_loss/max(val_total,1):.4f} | val_acc={val_acc:.2%}')
model.load_state_dict(best_state)
torch.save({'model_state_dict':model.state_dict(),'classes':CLASSES,'image_size':96,'normalization':'mean=0.5,std=0.5','architecture':'SmallCNN'},MODEL_PATH)
print(f'\nSaved model: {MODEL_PATH}')
print(f'Best validation accuracy: {best_acc:.2%} on {len(val_records)} validation images (very small validation set).')
print('Train images:',len(all_records),'Validation images:',len(val_records))
